import { useState } from "react";
import { DateTime } from "luxon";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { DriverReport } from "../driverReport.types";
import { reportDuration } from "../utils/reportSemantics";

export function performanceChartData(trends: DriverReport["trends"]) {
  return trends.map(row => ({ period: row.period, jobs: row.completedJobs,
    collected: row.completedJobs > 0 && row.unknownSystemCollectionJobs >= row.completedJobs ? null : row.systemKnownCollectionsPence / 100,
    hours: row.completedJobs > 0 && row.workingMinutesUnknownJobs >= row.completedJobs ? null : row.workingMinutesKnown / 60,
    missingHours: row.workingMinutesUnknownJobs, missingReceipts: row.unknownSystemCollectionJobs,
  })).sort((a, b) => a.period.localeCompare(b.period));
}
const currency = (value: number) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(value);
const metrics = {
  jobs: { title: "Completed jobs", unit: "Jobs", color: "#437ee8", format: (value: number) => `${value} jobs` },
  collected: { title: "Recorded receipts", unit: "GBP", color: "#169884", format: currency },
  hours: { title: "Working time", unit: "Hours", color: "#8770cb", format: (value: number) => reportDuration(value * 60) },
} as const;

export function DriverPerformanceCharts({ trends }: { trends: DriverReport["trends"] }) {
  const [selected, setSelected] = useState<keyof typeof metrics>("jobs"), data = performanceChartData(trends), metric = metrics[selected];
  return <section className="rpt-section rpt-performance-section" aria-label="Selected range performance charts"><div className="rpt-section-heading"><div><h2>Performance trend</h2><p className="rpt-muted">Daily recorded data · Selected range</p></div><label><span className="sr-only">Trend metric</span><select aria-label="Trend metric" value={selected} onChange={event => setSelected(event.target.value as keyof typeof metrics)}>{Object.entries(metrics).map(([key, item]) => <option key={key} value={key}>{item.title}</option>)}</select></label></div>
    {data.length && data.some(row => row[selected] !== null) ? <div className="rpt-chart" role="img" aria-label={`${metric.title} by date`}><ResponsiveContainer width="100%" height="100%"><BarChart data={data} margin={{ top: 12, right: 12, bottom: 8, left: 0 }}><CartesianGrid vertical={false} stroke="#e6ebf2" strokeDasharray="3 3" /><XAxis dataKey="period" tickFormatter={value => DateTime.fromISO(value).toFormat("dd LLL")} tick={{ fontSize: 12 }} minTickGap={28} axisLine={false} tickLine={false} /><YAxis width={60} allowDecimals={selected !== "jobs"} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={value => selected === "collected" ? `£${new Intl.NumberFormat("en-GB", { notation: "compact" }).format(value)}` : String(value)} /><Tooltip cursor={{ fill: "#f1f5fc" }} labelFormatter={value => DateTime.fromISO(String(value)).toFormat("ccc, dd LLL yyyy")} formatter={(value: number) => [metric.format(value), metric.title]} /><Bar dataKey={selected} name={metric.title} fill={metric.color} radius={[5, 5, 0, 0]} maxBarSize={42} isAnimationActive={false} /></BarChart></ResponsiveContainer></div> : <div className="rpt-empty">{data.length ? `${metric.title} unavailable for this range.` : "No jobs in this range."}</div>}
    {data.some(row => row.missingHours || row.missingReceipts) && <p className="rpt-note">Known subtotals only. Dates with entirely missing records have no bar; unpaid invoices are excluded from receipts.</p>}
    <details className="rpt-chart-data"><summary>View chart data</summary><div className="rpt-table-scroll"><table aria-label="Performance trend data"><thead><tr><th>Date · London</th><th>Completed jobs</th><th>Recorded receipts</th><th>Working time</th><th>Coverage</th></tr></thead><tbody>{data.map(row => <tr key={row.period}><th scope="row">{DateTime.fromISO(row.period).toFormat("dd LLL yyyy")}</th><td>{row.jobs}</td><td>{row.collected == null ? "Unverified" : `${row.missingReceipts ? "Known subtotal " : ""}${currency(row.collected)}`}</td><td>{row.hours == null ? "Not recorded" : `${row.missingHours ? "Known subtotal " : ""}${reportDuration(row.hours * 60)}`}</td><td>{row.missingHours || row.missingReceipts ? `${row.missingHours} timings missing · ${row.missingReceipts} receipt records unverified` : "Recorded"}</td></tr>)}</tbody></table></div></details>
  </section>;
}
