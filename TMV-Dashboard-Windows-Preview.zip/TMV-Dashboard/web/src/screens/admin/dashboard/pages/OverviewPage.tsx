import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DateTime } from "luxon";
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock3,
  CircleAlert,
  Users,
  RefreshCw,
  FileText,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { fetchSummary } from "../api";
import { AdminFilterBar } from "../components/AdminFilterBar";
import {
  DateRangePicker,
  defaultDashboardDateRange,
} from "../components/DateRangePicker";
import {
  PageHeader,
  MetricCard,
  DataState,
  CoverageNotice,
} from "../components/OperationsUI";
import { JobStatusBadge } from "../components/StatusBadge";
import {
  dailyRevenueSeries,
  fetchOverviewJobs,
  jobAttentionReasons,
} from "../utils/overview";
import { navigateAdmin, retainRangeInUrl } from "../utils/reportNavigation";
import { formatLondonDate, formatLondonTimeOnly } from "../utils/date";

interface Props {
  onSelectSection?: (id: string) => void;
}
const STATUS_COLORS = ["#2a5bd8", "#8c66d1", "#18a077", "#d97737"];

export function OverviewPage({ onSelectSection }: Props) {
  const [from, setFrom] = useState<string | undefined>(
    () =>
      new URLSearchParams(location.search).get("from") ||
      defaultDashboardDateRange().from,
  );
  const [to, setTo] = useState<string | undefined>(
    () =>
      new URLSearchParams(location.search).get("to") ||
      defaultDashboardDateRange().to,
  );
  const summary = useQuery({
    queryKey: ["summary", from, to],
    queryFn: () => fetchSummary(from, to),
  });
  const jobs = useQuery({
    queryKey: ["overview-jobs", from, to],
    queryFn: () => fetchOverviewJobs(from, to),
  });
  useEffect(() => {
    const read = () => {
      const params = new URLSearchParams(location.search);
      setFrom(params.get("from") || defaultDashboardDateRange().from);
      setTo(params.get("to") || defaultDashboardDateRange().to);
    };
    window.addEventListener("popstate", read);
    return () => window.removeEventListener("popstate", read);
  }, []);
  const attention = (jobs.data?.items || [])
    .map((job) => ({ job, reasons: jobAttentionReasons(job) }))
    .filter((item) => item.reasons.length);
  const isToday =
    from &&
    to &&
    DateTime.fromISO(from)
      .setZone("Europe/London")
      .hasSame(DateTime.now().setZone("Europe/London"), "day") &&
    DateTime.fromISO(to)
      .setZone("Europe/London")
      .hasSame(DateTime.now().setZone("Europe/London"), "day");
  const scope = isToday ? "Today" : "Selected range";
  const kpis = summary.data?.kpis;
  const chart = summary.data?.charts;
  const list = [...(jobs.data?.items || [])].sort((a, b) =>
    (a.bookedStart || "").localeCompare(b.bookedStart || ""),
  );
  function openJobs(status?: string) {
    const params = new URLSearchParams({ section: "jobs" });
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    if (status) params.set("status", status);
    navigateAdmin(location.pathname + "?" + params);
  }
  function openJob(id: string) {
    const url = new URL(location.href);
    url.searchParams.set("job", id);
    url.searchParams.set("section", "jobs");
    url.searchParams.set("recordReturn", location.pathname + location.search);
    navigateAdmin(url.pathname + url.search);
  }
  function openPerformance() {
    const params = new URLSearchParams({
      section: "drivers",
      driversTab: "performance",
    });
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    navigateAdmin(location.pathname + "?" + params);
  }
  const amount = (value: number | undefined) =>
    value == null || !Number.isFinite(value)
      ? "Not recorded"
      : new Intl.NumberFormat("en-GB", {
          style: "currency",
          currency: "GBP",
        }).format(value);
  const attentionValue = jobs.data?.complete
    ? attention.length
    : jobs.isError
      ? "Unavailable"
      : jobs.data
        ? `${attention.length}+`
        : "…";
  return (
    <div className="space-y-5 max-w-[1600px] mx-auto">
      <PageHeader
        eyebrow="THE MAN VAN / OPERATIONS"
        title="Operations overview"
        description={
          <>
            {scope} · {from ? formatLondonDate(from) : "All dates"}
            {!isToday && to && ` – ${formatLondonDate(to)}`} · London time
          </>
        }
        actions={
          <>
            <button className="ops-button secondary" onClick={openPerformance}>
              <Users size={16} />
              Driver performance
            </button>
            <button className="ops-button" onClick={() => openJobs()}>
              View jobs
              <ArrowRight size={16} />
            </button>
          </>
        }
      />
      <AdminFilterBar
        dates={
          <DateRangePicker
            from={from}
            to={to}
            onChange={(f, t) => {
              setFrom(f);
              setTo(t);
              retainRangeInUrl(f, t);
            }}
          />
        }
        count={summary.data ? `${kpis?.totalJobs} jobs in scope` : undefined}
      >
        <span className="text-xs text-admin-ink-2 flex items-center gap-2">
          <span className="w-2 h-2 bg-admin-brand rounded-full" />
          {summary.data?.meta.fetchedAt
            ? `Updated ${formatLondonTimeOnly(summary.data.meta.fetchedAt)}`
            : "Fetching current records"}
        </span>
        <button
          type="button"
          onClick={() => {
            void summary.refetch();
            void jobs.refetch();
          }}
          className="ops-text-action ml-auto"
          aria-label="Refresh overview"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </AdminFilterBar>
      {summary.isError && (
        <DataState
          kind="error"
          title="Summary could not load"
          description="Job records below remain available. Retry without changing your selected range."
          onRetry={() => void summary.refetch()}
        />
      )}
      <div className="ops-metric-grid" aria-label="Operational summary">
        <MetricCard
          label="Scheduled jobs"
          value={kpis?.scheduled ?? (summary.isError ? "Unavailable" : "…")}
          detail="Awaiting start · selected scope"
          icon={<CalendarDays size={18} />}
          onClick={() => openJobs("READY")}
        />
        <MetricCard
          label="In progress"
          value={kpis?.inProgress ?? (summary.isError ? "Unavailable" : "…")}
          detail="Active job workflow"
          tone="violet"
          icon={<Clock3 size={18} />}
          onClick={() => openJobs("IN_PROGRESS")}
        />
        <MetricCard
          label="Completed"
          value={kpis?.completed ?? (summary.isError ? "Unavailable" : "…")}
          detail="Payment and evidence separate"
          tone="green"
          icon={<CheckCircle2 size={18} />}
          onClick={() => openJobs("COMPLETED")}
        />
        <MetricCard
          label="Needs attention"
          value={attentionValue}
          detail={
            jobs.data?.complete
              ? "Jobs with recorded review reasons"
              : "Full coverage not yet verified"
          }
          tone="amber"
          icon={<CircleAlert size={18} />}
          onClick={() =>
            document
              .getElementById("needs-attention")
              ?.scrollIntoView({
                behavior: window.matchMedia("(prefers-reduced-motion: reduce)")
                  .matches
                  ? "auto"
                  : "smooth",
                block: "start",
              })
          }
        />
      </div>
      {jobs.data && !jobs.data.complete && (
        <CoverageNotice>
          Partial records: {jobs.data.items.length} of {jobs.data.total} jobs
          loaded. Attention is a known count, not a complete total.
        </CoverageNotice>
      )}
      <section id="needs-attention" className="ops-panel scroll-mt-20">
        <div className="ops-panel-header">
          <div>
            <h2>Needs attention</h2>
            <p>
              Recorded exceptions and incomplete submissions ·{" "}
              {scope.toLowerCase()}
            </p>
          </div>
          <button
            className="ops-text-action"
            onClick={() => onSelectSection?.("notifications")}
          >
            View alerts
            <ArrowRight size={14} />
          </button>
        </div>
        {jobs.isPending ? (
          <DataState kind="loading" title="Checking job records" />
        ) : jobs.isError ? (
          <DataState
            kind="error"
            title="Attention records could not load"
            description="A failed request does not mean there are no issues."
            onRetry={() => void jobs.refetch()}
          />
        ) : attention.length ? (
          <>
            {attention.slice(0, 4).map(({ job, reasons }) => (
              <div key={job.jobId} className="ops-attention-row">
                <span className="ops-attention-symbol">
                  <FileText size={17} />
                </span>
                <div className="min-w-0">
                  <h3>{reasons[0]}</h3>
                  <p>
                    {job.customerName || "Customer not recorded"} ·{" "}
                    {job.driverName || job.driverInitials || "Unassigned"} ·{" "}
                    {job.jobId}
                    {reasons.length > 1
                      ? ` · ${reasons.length - 1} more review reason${reasons.length > 2 ? "s" : ""}`
                      : ""}
                  </p>
                </div>
                <button
                  className="ops-text-action"
                  onClick={() => openJob(job.jobId)}
                >
                  Open job
                  <ArrowRight size={14} />
                </button>
              </div>
            ))}
            {attention.length > 4 && (
              <details className="p-4 text-sm">
                <summary className="cursor-pointer text-admin-brand font-semibold">
                  View {attention.length - 4} more jobs needing attention
                </summary>
                {attention.slice(4).map(({ job, reasons }) => (
                  <div className="ops-attention-row" key={job.jobId}>
                    <div>
                      <h3>{reasons[0]}</h3>
                      <p>
                        {job.customerName} · {job.jobId}
                      </p>
                    </div>
                    <button
                      className="ops-text-action"
                      onClick={() => openJob(job.jobId)}
                    >
                      Open job
                      <ArrowRight size={14} />
                    </button>
                  </div>
                ))}
              </details>
            )}
          </>
        ) : (
          <DataState
            kind="empty"
            title={
              jobs.data?.complete
                ? "No recorded job issues in this scope"
                : "No issues in the loaded records"
            }
            description="This checks recorded exceptions, failed uploads, overdue arrival proof, stale trackers, pending invoices and missing completed-job submissions. It does not certify that every operational issue is known."
          />
        )}
      </section>
      <section className="ops-panel">
        <div className="ops-panel-header">
          <div>
            <h2>{isToday ? "Today's jobs" : "Jobs in this range"}</h2>
            <p>Schedule, assignment and workflow at a glance</p>
          </div>
          <button className="ops-text-action" onClick={() => openJobs()}>
            All jobs
            <ArrowRight size={14} />
          </button>
        </div>
        {jobs.isPending ? (
          <DataState kind="loading" title="Loading jobs" />
        ) : jobs.isError ? (
          <DataState
            kind="error"
            title="Jobs could not load"
            onRetry={() => void jobs.refetch()}
          />
        ) : list.length ? (
          <>
            <table className="ops-overview-table">
              <thead>
                <tr>
                  <th>Scheduled</th>
                  <th>Customer & route</th>
                  <th>Driver</th>
                  <th>Job status</th>
                  <th>
                    <span className="sr-only">Action</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {list.slice(0, 8).map((job) => (
                  <tr key={job.jobId}>
                    <td>
                      <span className="font-semibold">
                        {formatLondonTimeOnly(job.bookedStart)}
                      </span>
                      {!isToday && (
                        <div className="ops-record-meta">
                          {formatLondonDate(job.bookedStart)}
                        </div>
                      )}
                    </td>
                    <td>
                      <div className="ops-record-name">
                        {job.customerName || "Customer not recorded"}
                      </div>
                      <div className="ops-record-meta break-words">
                        {job.pickup || "Pickup not recorded"} →{" "}
                        {job.dropoff || "Dropoff not recorded"}
                      </div>
                    </td>
                    <td>
                      {job.driverName || job.driverInitials || "Unassigned"}
                    </td>
                    <td>
                      <JobStatusBadge status={job.status} />
                    </td>
                    <td>
                      <button
                        className="ops-text-action"
                        onClick={() => openJob(job.jobId)}
                        aria-label={`Open job ${job.jobId}`}
                      >
                        Open
                        <ArrowRight size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {list.length > 8 && (
              <div className="px-5 py-3 text-xs text-admin-ink-2">
                Showing the first 8 of {list.length} loaded jobs.{" "}
                <button
                  onClick={() => openJobs()}
                  className="text-admin-brand font-semibold"
                >
                  View complete list
                </button>
              </div>
            )}
          </>
        ) : (
          <DataState
            kind="empty"
            title="No jobs in this range"
            description="Choose a different date range to view bookings."
          />
        )}
      </section>
      {chart && (
        <div className="ops-chart-grid">
          <section className="ops-panel">
            <div className="ops-panel-header">
              <div>
                <h2>Daily billed revenue</h2>
                <p>Summary API billed values · not bank receipts</p>
              </div>
              <span className="ops-metric-icon">
                <span className="font-semibold">£</span>
              </span>
            </div>
            <div className="ops-chart-body">
              <div className="ops-chart-total">
                {amount(kpis?.revenuePounds)}
                <small>Selected range</small>
              </div>
              {chart.revenueOverTime.length ? (
                <>
                  <div
                    className="h-[205px] mt-5"
                    aria-label="Daily billed revenue chart"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={dailyRevenueSeries(chart.revenueOverTime)}
                        margin={{ left: 0, right: 12, top: 10, bottom: 0 }}
                      >
                        <CartesianGrid vertical={false} stroke="#edf0f5" />
                        <XAxis
                          dataKey="date"
                          tickFormatter={(value) =>
                            DateTime.fromISO(value).toFormat("d LLL")
                          }
                          tick={{ fontSize: 11, fill: "#5e6e83" }}
                          axisLine={false}
                          tickLine={false}
                          minTickGap={35}
                        />
                        <YAxis
                          width={56}
                          tick={{ fontSize: 11, fill: "#5e6e83" }}
                          tickFormatter={(value) => `£${value}`}
                          axisLine={false}
                          tickLine={false}
                        />
                        <Tooltip
                          labelFormatter={(value) =>
                            formatLondonDate(String(value))
                          }
                          formatter={(value: number) => [
                            amount(value),
                            "Billed revenue",
                          ]}
                          contentStyle={{
                            borderRadius: 8,
                            borderColor: "#e3e8f0",
                            fontSize: 13,
                          }}
                        />
                        <Area
                          type="linear"
                          dataKey="revenuePounds"
                          stroke="#2a5bd8"
                          strokeWidth={2.5}
                          fill="#edf3ff"
                          connectNulls={false}
                          isAnimationActive={false}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <details className="ops-chart-data">
                    <summary>View daily values and basis</summary>
                    <p>
                      Reported billed turnover; cash/card summaries can have a
                      different coverage and basis. No ledger or bank balance is
                      inferred. Missing dates are not inserted as zero.
                    </p>
                    <table>
                      <thead>
                        <tr>
                          <th>Date · London</th>
                          <th>Billed revenue</th>
                          <th>Jobs</th>
                        </tr>
                      </thead>
                      <tbody>
                        {chart.revenueOverTime.map((row) => (
                          <tr key={row.date}>
                            <td>{formatLondonDate(row.date)}</td>
                            <td>{amount(row.revenuePounds)}</td>
                            <td>{row.jobsCount}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </details>
                </>
              ) : (
                <DataState
                  kind="empty"
                  title="No daily billed values recorded"
                />
              )}
            </div>
          </section>
          <section className="ops-panel">
            <div className="ops-panel-header">
              <div>
                <h2>Job status</h2>
                <p>Every reported status in the selected range</p>
              </div>
            </div>
            <div className="ops-chart-body">
              {chart.statusBreakdown.some((row) => row.value > 0) ? (
                <div className="flex items-center gap-6 flex-wrap">
                  <div className="w-[145px] h-[145px] relative">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={chart.statusBreakdown}
                          dataKey="value"
                          innerRadius={51}
                          outerRadius={68}
                          paddingAngle={3}
                          stroke="none"
                          isAnimationActive={false}
                        >
                          {chart.statusBreakdown.map((row, index) => (
                            <Cell
                              key={row.label}
                              fill={STATUS_COLORS[index % 4]}
                            />
                          ))}
                        </Pie>
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <strong className="text-2xl">{kpis?.totalJobs}</strong>
                      <span className="text-xs text-admin-ink-2">
                        Total jobs
                      </span>
                    </div>
                  </div>
                  <div className="flex-1 min-w-[120px]">
                    {chart.statusBreakdown.map((row, index) => (
                      <div className="ops-status-row" key={row.label}>
                        <span
                          className="ops-status-dot"
                          style={{ background: STATUS_COLORS[index % 4] }}
                        />
                        {(
                          {
                            READY: "Scheduled",
                            IN_PROGRESS: "In progress",
                            COMPLETED: "Completed",
                            CANCELLED: "Cancelled",
                          } as Record<string, string>
                        )[row.label] || row.label}
                        <strong>{row.value}</strong>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <DataState kind="empty" title="No jobs in scope" />
              )}
              <p className="text-xs text-admin-ink-2 mt-5">
                Workflow status is independent of payment, evidence and manager
                review.
              </p>
              {kpis &&
                chart.statusBreakdown.reduce(
                  (sum, row) => sum + row.value,
                  0,
                ) !== kpis.totalJobs && (
                  <CoverageNotice>
                    Status counts do not cover the reported job total. The
                    summary source needs review; no remainder has been
                    reclassified.
                  </CoverageNotice>
                )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
