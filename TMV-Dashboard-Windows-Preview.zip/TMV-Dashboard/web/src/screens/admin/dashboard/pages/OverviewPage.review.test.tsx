import React from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { OverviewPage } from "./OverviewPage";
const { fetchSummary, fetchOverviewJobs } = vi.hoisted(() => ({
  fetchSummary: vi.fn(),
  fetchOverviewJobs: vi.fn(),
}));
vi.mock("../api", () => ({ fetchSummary }));
vi.mock("../utils/overview", async (original) => ({
  ...(await original<typeof import("../utils/overview")>()),
  fetchOverviewJobs,
}));
vi.mock("../components/DateRangePicker", () => ({
  DateRangePicker: () => null,
  defaultDashboardDateRange: () => ({ from: "2026-10-13", to: "2026-10-13" }),
}));
const summary = {
  kpis: { scheduled: 1, inProgress: 1, completed: 1, totalJobs: 3 },
  charts: { statusBreakdown: [], revenueOverTime: [] },
  meta: { fetchedAt: "2026-10-13T12:00:00Z" },
};
const job = {
  jobId: "SAFE-1",
  status: "COMPLETED",
  bookedStart: "2026-10-13T09:00:00Z",
  customerName: "Synthetic Customer",
  pickup: "Sample pickup",
  dropoff: "Sample dropoff",
  driverName: "Sample Driver",
  exceptions: [],
  evidenceCompleteness: {},
};
function mount() {
  render(
    <QueryClientProvider
      client={
        new QueryClient({ defaultOptions: { queries: { retry: false } } })
      }
    >
      <OverviewPage />
    </QueryClientProvider>,
  );
}
beforeEach(() => {
  vi.clearAllMocks();
  history.replaceState({}, "", "/admin?section=overview");
  fetchSummary.mockResolvedValue(summary);
  fetchOverviewJobs.mockResolvedValue({
    items: [job],
    total: 1,
    complete: true,
  });
});
describe("operational overview", () => {
  it("starts with daily work and opens the exact attention job with return context", async () => {
    mount();
    expect(
      await screen.findByText("Driver submission not recorded"),
    ).toBeInTheDocument();
    expect(screen.queryByText("Driver Breakdown")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Open job" }));
    const params = new URLSearchParams(location.search);
    expect(params.get("job")).toBe("SAFE-1");
    expect(params.get("recordReturn")).toContain("section=overview");
  });
  it("retains partial-count coverage instead of implying a complete exception count", async () => {
    fetchOverviewJobs.mockResolvedValue({
      items: [job],
      total: 3,
      complete: false,
    });
    mount();
    expect(
      await screen.findByText(/Partial records: 1 of 3/),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "View needs attention" }),
    ).toHaveTextContent("1+");
  });
  it("does not render failed loading as zero jobs or no issues", async () => {
    fetchOverviewJobs.mockRejectedValue(new Error("offline"));
    mount();
    expect(
      await screen.findByText("Attention records could not load"),
    ).toBeInTheDocument();
    expect(
      screen.queryByText("No recorded job issues in this scope"),
    ).not.toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "View needs attention" }),
    ).toHaveTextContent("Unavailable");
  });
  it("moves performance to Drivers while retaining range", async () => {
    mount();
    await waitFor(() =>
      expect(
        screen.getByRole("button", { name: "Driver performance" }),
      ).toBeInTheDocument(),
    );
    fireEvent.click(screen.getByRole("button", { name: "Driver performance" }));
    const params = new URLSearchParams(location.search);
    expect(params.get("section")).toBe("drivers");
    expect(params.get("driversTab")).toBe("performance");
    expect(params.get("from")).toBe("2026-10-13");
  });
});
